# Configuração do Sharko (Dify + Supabase)

## Variáveis de ambiente

Configure estas quatro variáveis no Render (Environment) ou no arquivo `.env` local:

- `DIFY_API_URL`: `https://api.dify.ai/v1` (ou a URL da sua instalação Dify).
- `DIFY_API_KEY`: chave da API criada dentro do aplicativo Dify.
- `SUPABASE_URL`: URL do seu projeto Supabase.
- `SUPABASE_ANON_KEY`: chave publicável/anon do Supabase. **Nunca use a service_role/secret key no navegador.**

A chave do Dify fica somente no servidor. A URL do Supabase e a chave publicável são servidas ao frontend em tempo de execução por `/api/config`; o servidor valida a sessão antes de encaminhar cada mensagem ao Dify. Este projeto usa React com Rspack (não Next.js ou Vite), então usa `SUPABASE_URL` e `SUPABASE_ANON_KEY`, sem prefixos `NEXT_PUBLIC_` ou `VITE_`. O `.gitignore` ignora `.env*`, mantendo `.env.example` versionado. O servidor lê `.env`; `.env.local` não é necessário.

## Dify

1. Crie/publique um aplicativo de conversa (Chatbot ou Chatflow) no Dify.
2. Abra a área de acesso à API desse aplicativo e crie uma API Key.
3. Copie a chave para `DIFY_API_KEY`.
4. Para Dify Cloud, mantenha `DIFY_API_URL=https://api.dify.ai/v1`. Em instalação própria, use a URL base da API da sua instância.

A configuração de modelo, prompt, conhecimento e ferramentas continua sendo feita dentro do Dify. O Sharko chama o endpoint `/chat-messages`.

Para responder a fotos, habilite o envio de imagens nas configurações de recursos do aplicativo Dify e use um modelo/nó de LLM com visão. O Dify Cloud limita imagens a 10 MB; o Sharko valida esse limite antes do upload. Se o aplicativo ou modelo não aceitar imagens, o Dify não conseguirá analisá-las.

Como a integração ativa é com a API de chat do Dify, o modelo e seus parâmetros (como `temperature`, `presence_penalty` e `stop`) devem ser definidos na configuração do aplicativo/nó de modelo no Dify. O endpoint usado pelo servidor não recebe esses parâmetros por mensagem. Para usar DeepSeek-V4.1-Flash, selecione-o no Dify se estiver disponível para o provedor configurado. O prompt incluído no frontend não substitui o system prompt configurado no aplicativo Dify.

Para configurar o comportamento solicitado, abra o aplicativo no Studio do Dify, selecione o modelo/nó de LLM e, se o provedor disponibilizar esses controles, configure:

- Modelo: `DeepSeek-V4.1-Flash`
- Temperature: `1.0`
- Presence penalty: `0.1`
- Stop sequences: `<｜end▁of▁sentence｜>` e `<|im_end|>`

No system prompt do aplicativo Dify, cole o prompt Sharko definido em `src/services/chat/store.ts` e publique uma nova versão do aplicativo. A constante no frontend não altera o system prompt do Dify, pois a API de chat do Dify não aceita esse campo na requisição.

## Supabase e login

1. Crie um projeto Supabase.
2. Copie Project URL para `SUPABASE_URL`.
3. Copie a chave `anon`/publishable para `SUPABASE_ANON_KEY`.
4. Em Authentication → URL Configuration, defina o Site URL para um domínio estável (em produção, o domínio de produção) e adicione estas URLs à lista de Redirect URLs. Para testar no Codespaces, mantenha o padrão curinga e, se necessário, adicione também a URL atual exata terminada em `/chat`:
   - Local: `http://localhost:3000/**`
   - GitHub Codespaces com a porta 3000 encaminhada: `https://*-3000.app.github.dev/**`
   - Produção: o domínio real do Sharko, por exemplo `https://sharko.seudominio.com/**`

   O app usa `https://<origem-atual>/chat` como URL de retorno do login. Essa URL precisa estar na lista de Redirect URLs; caso contrário, o Supabase pode redirecionar para o Site URL padrão, que não deve apontar para um Codespace antigo ou temporário.
5. Para permitir login tradicional, habilite o provedor Email em Authentication → Providers → Email. A confirmação de e-mail pode ser configurada nessa área; se estiver ativa, novos usuários precisarão confirmar a conta antes de entrar.
6. No Google Cloud Console, abra APIs e serviços → Credenciais → Criar credenciais → ID do cliente OAuth → Aplicativo da Web. Copie o **Client ID** e o **Client Secret**. No Supabase, abra Authentication → Providers → Google, habilite Google e cole os dois valores nos campos correspondentes. Não coloque o Client Secret no `.env` nem no código do app.
7. No Google Cloud Console, no mesmo cliente OAuth, adicione esta URI em **URIs de redirecionamento autorizados**:

   `https://hhcusxeloksehhozvnwa.supabase.co/auth/v1/callback`

   Essa URI é o callback do projeto Supabase usado pelo app. Não use `http://localhost:3000` como URI de redirecionamento autorizada do Google: o Google retorna primeiro ao Supabase, que então redireciona ao Sharko. Se usar outro projeto Supabase, substitua a URL acima por `<SUPABASE_URL>/auth/v1/callback`.

8. Se o app OAuth do Google estiver em modo de teste, adicione a conta Google usada para testar como usuário de teste na tela de consentimento.

O Sharko usa o cliente oficial `@supabase/supabase-js` para cadastro/login por e-mail e senha, login Google OAuth via Supabase, persistência/renovação de sessão e logout. No cliente OAuth do Google, a URI autorizada continua sendo `<SUPABASE_URL>/auth/v1/callback`; ela é diferente das Redirect URLs do app configuradas no passo 4.

## Notícias, vagas e candidaturas

1. Execute [`supabase/schema.sql`](./supabase/schema.sql) no SQL Editor do projeto Supabase. O script cria as tabelas, índices, políticas RLS e regras de acesso público para leitura de conteúdo e envio de candidaturas.
2. No SQL Editor, dê acesso de administrador à conta que administrará o site (substitua pelo e-mail usado no login):
   ```sql
   update auth.users
   set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
   where email = 'seu-email@exemplo.com';
   ```
   Isso grava a função em `app_metadata`, não em `user_metadata`. Saia e entre novamente para renovar o token.
3. Entre em `/admin` para criar/editar notícias em inglês e português, cadastrar/fechar vagas em inglês e acompanhar as candidaturas. A data da notícia é preenchida automaticamente pelo banco.
4. Visitantes leem notícias publicadas em `/research-news`, veem vagas abertas em `/careers` e enviam candidaturas pelo formulário. Apenas administradores podem listar as candidaturas.

## Executar localmente

```bash
cp .env.example .env
# preencha as quatro variáveis no .env
pnpm install
pnpm build
pnpm start:local
```

Abra `http://localhost:3000`. `pnpm start:local` desativa o login apenas para testes locais e limita o servidor a `127.0.0.1`; não compartilhe nem publique esse modo. Para iniciar com autenticação, use `pnpm start`. O arquivo `.env` não deve ser enviado ao GitHub.

## Publicar no Render

O arquivo `render.yaml` define build e start. No painel do serviço, preencha `DIFY_API_KEY`, `SUPABASE_URL` e `SUPABASE_ANON_KEY`; `DIFY_API_URL` já tem o padrão do Dify Cloud.

## O que esta integração cobre

- Cadastro/login por e-mail e senha e autenticação Google OAuth pelo Supabase (desde que os provedores estejam habilitados).
- Chat de texto com resposta em streaming via Dify.
- Envio de anexos para o endpoint de arquivos do Dify, quando o aplicativo Dify aceitar arquivos.
- A chave privada do Dify fica no servidor.
- Histórico local separado por conta neste navegador/dispositivo.

O histórico ainda não é sincronizado entre dispositivos no banco Supabase. Recursos de voz/ASR/TTS e controles específicos da API DeepSeek (como ferramentas nativas de busca e modo de raciocínio) não são equivalentes diretos da API Dify e precisam de integração própria ou configuração no aplicativo Dify.
