# Sharko

Landing page do Sharko e interface de IA integradas no mesmo site:

- `/` abre a landing page.
- `/chat` abre o chat do Sharko.

## Teste local

1. Instale as dependências com `pnpm install`.
2. Copie `.env.example` para `.env` e configure `DIFY_API_KEY` com a chave privada do seu app Dify. A chave fica somente no servidor.
3. Gere os arquivos do site com `pnpm build`.
4. Configure também `SUPABASE_URL` e `SUPABASE_ANON_KEY` no `.env` e inicie o servidor com `pnpm start` para usar o login original.
5. Abra `http://localhost:3000` no Google Chrome. Digite no campo da landing e pressione Enter ou o botão de envio para abrir o chat e enviar essa mesma mensagem à IA. O link **Try Sharko AI** abre uma conversa vazia.

O prompt fica guardado temporariamente nesta sessão do navegador durante o login e é enviado ao chat depois da autenticação. Configure o provedor Google no Supabase se quiser testar esse método de login. `pnpm start:local` desativa a autenticação e serve apenas para testes sem login; não o use em produção.

## Notícias, vagas e candidaturas

1. Execute [`supabase/schema.sql`](./supabase/schema.sql) no SQL Editor do projeto Supabase.
2. No SQL Editor, torne sua conta administradora (troque pelo e-mail usado no login):
   ```sql
   update auth.users
   set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
   where email = 'seu-email@exemplo.com';
   ```
   Saia e entre novamente para atualizar a sessão.
3. Abra `/admin` para publicar notícias em português e inglês, gerenciar vagas em inglês e acompanhar candidaturas. A data das notícias é gerada automaticamente pelo banco.
4. As páginas públicas ficam em `/research-news` e `/careers`. Candidaturas são enviadas pelo formulário do site; somente administradores podem consultá-las.
5. Para enviar automaticamente um e-mail ao marcar uma candidatura como **Contratada** ou **Recusada**, crie uma API key no Resend e verifique seu domínio remetente. Configure `RESEND_API_KEY` e `RESEND_FROM_EMAIL` no ambiente do servidor (ou no `.env` local), execute novamente `supabase/schema.sql` para adicionar o campo de registro de envio e reinicie o servidor. Se o envio falhar, o painel mostra o erro e permite tentar novamente.

A autorização é aplicada por Row Level Security no Supabase; não conceda a função de admin usando `user_metadata`.
