# Sharko

本项目使用 Dify 作为 AI 服务，并使用 Supabase 提供用户身份验证。

请查看葡萄牙语配置说明：[SETUP-AETEL-PT-BR.md](SETUP-AETEL-PT-BR.md)。

需要配置环境变量：`DIFY_API_URL`、`DIFY_API_KEY`、`SUPABASE_URL` 和 `SUPABASE_ANON_KEY`。Dify 私钥只保存在服务器环境变量中，不要提交到 GitHub。

运行：`pnpm install`、`pnpm build`、`pnpm start`。
