import { useEffect, useState } from 'react'
import { AuthScreen } from '../components/auth/AuthScreen.js'
import { initAuth, signOut, useAuth } from '../services/auth.js'
import { configureSupabase } from '../services/supabase.js'
import { AdminPage } from './AdminPage.js'
import { CareersPage } from './CareersPage.js'
import { NewsPage } from './NewsPage.js'
import './site.css'

export type SiteLocale = 'en' | 'pt'

const LOCALE_KEY = 'sharko:site-locale'
const isPortuguese = (value: string | null): value is 'pt' => value === 'pt'

const SiteHeader = ({
  locale,
  onLocaleChange,
  admin,
}: {
  locale: SiteLocale
  onLocaleChange: (locale: SiteLocale) => void
  admin: boolean
}) => (
  <header className="site-header">
    <a className="site-brand" href="/" aria-label="Sharko home">
      <img src="/sharko-icon.png" alt="" />
      <span>sharko</span>
    </a>
    <nav aria-label="Main navigation">
      <a href="/research-news">{locale === 'pt' ? 'Notícias' : 'News'}</a>
      <a href="/careers">{locale === 'pt' ? 'Carreiras' : 'Careers'}</a>
      {admin ? <a href="/admin">{locale === 'pt' ? 'Administração' : 'Admin'}</a> : null}
      <a href="/chat">{locale === 'pt' ? 'IA Sharko' : 'Sharko AI'}</a>
      <div className="site-language" aria-label="Language">
        <button
          type="button"
          className={locale === 'pt' ? 'selected' : ''}
          aria-pressed={locale === 'pt'}
          onClick={() => onLocaleChange('pt')}
        >
          PT
        </button>
        <button
          type="button"
          className={locale === 'en' ? 'selected' : ''}
          aria-pressed={locale === 'en'}
          onClick={() => onLocaleChange('en')}
        >
          EN
        </button>
      </div>
      {admin ? (
        <button className="site-signout" type="button" onClick={() => void signOut()}>
          {locale === 'pt' ? 'Sair' : 'Sign out'}
        </button>
      ) : null}
    </nav>
  </header>
)

const SiteFooter = ({ locale }: { locale: SiteLocale }) => (
  <footer className="site-footer">
    <a href="/">Sharko</a>
    <span>
      © {new Date().getFullYear()} Sharko
      {locale === 'pt' ? ' · Todos os direitos reservados' : ' · All rights reserved'}
    </span>
  </footer>
)

export const SiteApp = () => {
  const [locale, setLocale] = useState<SiteLocale>(() =>
    isPortuguese(localStorage.getItem(LOCALE_KEY)) ? 'pt' : 'en'
  )
  const [siteClientReady, setSiteClientReady] = useState(false)
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/'
  const isAdminPage = pathname === '/admin'
  const authReady = useAuth((state) => state.ready)
  const config = useAuth((state) => state.config)
  const user = useAuth((state) => state.user)
  const isAdmin = user?.app_metadata?.role === 'admin'

  useEffect(() => {
    void initAuth()
  }, [])

  useEffect(() => {
    if (!authReady) {
      return
    }
    if (config?.configured) {
      configureSupabase(config.supabaseUrl, config.supabaseAnonKey)
    }
    setSiteClientReady(true)
  }, [authReady, config])

  useEffect(() => {
    localStorage.setItem(LOCALE_KEY, locale)
    document.documentElement.lang = locale === 'pt' ? 'pt-BR' : 'en'
  }, [locale])

  let content
  if (isAdminPage) {
    if (!authReady || !siteClientReady) {
      content = <div className="site-state">Loading Sharko…</div>
    } else if (!siteClientReady || !config?.configured) {
      content = (
        <div className="site-state site-error">
          Supabase is not configured. Configure the server environment before using the admin panel.
        </div>
      )
    } else if (!user) {
      content = <AuthScreen />
    } else if (!isAdmin) {
      content = (
        <div className="site-state site-error">
          {locale === 'pt'
            ? 'Esta conta não tem acesso ao painel administrativo.'
            : 'This account does not have access to the admin panel.'}
        </div>
      )
    } else {
      content = <AdminPage locale={locale} />
    }
  } else if (!authReady || !siteClientReady || !config?.configured) {
    content = (
      <div className="site-state">
        {!authReady
          ? 'Loading Sharko…'
          : 'Supabase is not configured. Configure the server environment to load site content.'}
      </div>
    )
  } else if (pathname === '/careers') {
    content = <CareersPage />
  } else {
    content = <NewsPage locale={locale} />
  }

  return (
    <div className="site-shell">
      <SiteHeader locale={locale} onLocaleChange={setLocale} admin={isAdmin} />
      <main className="site-main">{content}</main>
      <SiteFooter locale={locale} />
    </div>
  )
}
