import { useEffect, useState, type FormEvent } from 'react'
import { getSupabaseClient } from '../services/supabase.js'

type Job = {
  id: string
  title: string
  department: string
  location: string
  employment_type: string
  description: string
}

const ApplicationForm = ({ job, onClose }: { job: Job; onClose: () => void }) => {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (busy) {
      return
    }
    setBusy(true)
    setError('')
    const form = new FormData(event.currentTarget)
    const { error: requestError } = await getSupabaseClient().from('job_applications').insert({
      job_id: job.id,
      full_name: String(form.get('full_name') ?? '').trim(),
      email: String(form.get('email') ?? '').trim(),
      phone: String(form.get('phone') ?? '').trim(),
      linkedin_url: String(form.get('linkedin_url') ?? '').trim(),
      resume_url: String(form.get('resume_url') ?? '').trim(),
      cover_letter: String(form.get('cover_letter') ?? '').trim(),
    })
    if (requestError) {
      setError(requestError.message)
      setBusy(false)
      return
    }
    setSubmitted(true)
    setBusy(false)
  }

  if (submitted) {
    return (
      <div className="application-success" role="status">
        <h3>Application received</h3>
        <p>Thank you for applying to {job.title}. Our team will be in touch if there is a match.</p>
        <button type="button" className="site-button" onClick={onClose}>Close</button>
      </div>
    )
  }

  return (
    <form className="application-form" onSubmit={(event) => void submit(event)}>
      <div className="form-heading">
        <div>
          <p className="site-eyebrow">Apply for</p>
          <h3>{job.title}</h3>
        </div>
        <button type="button" className="site-text-button" onClick={onClose}>Close</button>
      </div>
      <label>Full name<input name="full_name" required maxLength={160} autoComplete="name" /></label>
      <label>Email<input name="email" type="email" required maxLength={320} autoComplete="email" /></label>
      <label>Phone<input name="phone" type="tel" maxLength={80} autoComplete="tel" /></label>
      <label>LinkedIn<input name="linkedin_url" type="url" maxLength={1000} placeholder="https://linkedin.com/in/..." /></label>
      <label>Resume or portfolio link<input name="resume_url" type="url" maxLength={1000} placeholder="https://" /></label>
      <label>Cover letter<textarea name="cover_letter" rows={5} maxLength={10000} /></label>
      {error ? <p className="site-error" role="alert">{error}</p> : null}
      <button className="site-button" type="submit" disabled={busy}>
        {busy ? 'Sending…' : 'Submit application'}
      </button>
    </form>
  )
}

export const CareersPage = () => {
  const [jobs, setJobs] = useState<Job[]>([])
  const [selectedJob, setSelectedJob] = useState<Job | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    void getSupabaseClient()
      .from('jobs')
      .select('id,title,department,location,employment_type,description')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .then(({ data, error: requestError }) => {
        if (!active) {
          return
        }
        if (requestError) {
          setError(requestError.message)
        } else {
          setJobs((data ?? []) as Job[])
        }
        setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  return (
    <section className="site-content">
      <p className="site-eyebrow">Join Sharko</p>
      <h1>Careers</h1>
      <p className="site-intro">Help us build useful AI products and bring new ideas to life.</p>
      {loading ? <p className="site-state">Loading open positions…</p> : null}
      {error ? <p className="site-error" role="alert">{error}</p> : null}
      {!loading && !error && jobs.length === 0 ? (
        <p className="site-empty">There are no open positions right now. Please check back soon.</p>
      ) : null}
      <div className="job-list">
        {jobs.map((job) => (
          <article className="job-card" key={job.id}>
            <div>
              <h2>{job.title}</h2>
              <p className="job-meta">
                {[job.department, job.location, job.employment_type].filter(Boolean).join(' · ')}
              </p>
              <p className="job-description">{job.description}</p>
            </div>
            <button type="button" className="site-button" onClick={() => setSelectedJob(job)}>
              Apply
            </button>
          </article>
        ))}
      </div>
      {selectedJob ? (
        <div className="site-modal-backdrop" role="presentation" onClick={() => setSelectedJob(null)}>
          <div
            className="site-modal"
            role="dialog"
            aria-modal="true"
            aria-label={`Apply for ${selectedJob.title}`}
            onClick={(event) => event.stopPropagation()}
          >
            <ApplicationForm job={selectedJob} onClose={() => setSelectedJob(null)} />
          </div>
        </div>
      ) : null}
    </section>
  )
}
