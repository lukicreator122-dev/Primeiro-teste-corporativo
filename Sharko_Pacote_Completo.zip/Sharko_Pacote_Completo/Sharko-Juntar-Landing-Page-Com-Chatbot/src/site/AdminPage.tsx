import { useEffect, useState, type FormEvent } from 'react'
import { getSupabaseClient } from '../services/supabase.js'
import { getAccessToken, useAuth } from '../services/auth.js'
import type { SiteLocale } from './SiteApp.js'

type NewsArticle = {
  id: string
  title_en: string
  title_pt: string
  summary_en: string
  summary_pt: string
  body_en: string
  body_pt: string
  is_published: boolean
  published_at: string
}

type Job = {
  id: string
  title: string
  department: string
  location: string
  employment_type: string
  description: string
  is_active: boolean
  created_at: string
}

type Application = {
  id: string
  job_id: string
  full_name: string
  email: string
  phone: string
  linkedin_url: string
  resume_url: string
  cover_letter: string
  status: ApplicationStatus
  created_at: string
  decision_email_sent_at: string | null
}

type ApplicationStatus = 'new' | 'reviewing' | 'interview' | 'hired' | 'rejected'
type Tab = 'news' | 'jobs' | 'applications'

const EMPTY_ARTICLE = {
  title_en: '',
  title_pt: '',
  summary_en: '',
  summary_pt: '',
  body_en: '',
  body_pt: '',
  is_published: true,
}

const EMPTY_JOB = {
  title: '',
  department: '',
  location: '',
  employment_type: 'Full-time',
  description: '',
  is_active: true,
}

const formValue = (form: FormData, key: string) => String(form.get(key) ?? '').trim()
const formatDate = (date: string, locale: SiteLocale) =>
  new Intl.DateTimeFormat(locale === 'pt' ? 'pt-BR' : 'en-US', { dateStyle: 'medium' }).format(
    new Date(date)
  )

export const AdminPage = ({ locale }: { locale: SiteLocale }) => {
  const [tab, setTab] = useState<Tab>('news')
  const t = locale === 'pt'
  return (
    <section className="site-content admin-content">
      <p className="site-eyebrow">Sharko</p>
      <h1>{t ? 'Painel administrativo' : 'Admin dashboard'}</h1>
      <div className="admin-tabs" role="tablist">
        {(['news', 'jobs', 'applications'] as const).map((item) => (
          <button
            type="button"
            role="tab"
            aria-selected={tab === item}
            className={tab === item ? 'selected' : ''}
            key={item}
            onClick={() => setTab(item)}
          >
            {item === 'news' ? (t ? 'Notícias' : 'News') : null}
            {item === 'jobs' ? (t ? 'Vagas' : 'Jobs') : null}
            {item === 'applications' ? (t ? 'Candidaturas' : 'Applications') : null}
          </button>
        ))}
      </div>
      {tab === 'news' ? <NewsAdmin locale={locale} /> : null}
      {tab === 'jobs' ? <JobsAdmin locale={locale} /> : null}
      {tab === 'applications' ? <ApplicationsAdmin locale={locale} /> : null}
    </section>
  )
}

const NewsAdmin = ({ locale }: { locale: SiteLocale }) => {
  const user = useAuth((state) => state.user)
  const [articles, setArticles] = useState<NewsArticle[]>([])
  const [editing, setEditing] = useState<NewsArticle | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const t = locale === 'pt'

  const load = async () => {
    setLoading(true)
    const { data, error: requestError } = await getSupabaseClient()
      .from('news_articles')
      .select('*')
      .order('published_at', { ascending: false })
    if (requestError) {
      setError(requestError.message)
    } else {
      setArticles((data ?? []) as NewsArticle[])
      setError('')
    }
    setLoading(false)
  }

  useEffect(() => {
    void load()
  }, [])

  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (busy) {
      return
    }
    setBusy(true)
    setError('')
    const formElement = event.currentTarget
    const form = new FormData(formElement)
    const values = {
      title_en: formValue(form, 'title_en'),
      title_pt: formValue(form, 'title_pt'),
      summary_en: formValue(form, 'summary_en'),
      summary_pt: formValue(form, 'summary_pt'),
      body_en: formValue(form, 'body_en'),
      body_pt: formValue(form, 'body_pt'),
      is_published: form.get('is_published') === 'on',
    }
    const query = editing
      ? getSupabaseClient().from('news_articles').update(values).eq('id', editing.id)
      : getSupabaseClient()
          .from('news_articles')
          .insert({ ...values, created_by: user?.id ?? null })
    const { error: requestError } = await query
    if (requestError) {
      setError(requestError.message)
      setBusy(false)
      return
    }
    setEditing(null)
    formElement.reset()
    setBusy(false)
    await load()
  }

  const cancelEdit = (form: HTMLFormElement | null) => {
    setEditing(null)
    form?.reset()
  }

  return (
    <div className="admin-grid">
      <form key={editing?.id ?? 'new-news'} className="admin-form" onSubmit={(event) => void save(event)}>
        <h2>{editing ? (t ? 'Editar notícia' : 'Edit news') : (t ? 'Nova notícia' : 'New news')}</h2>
        <div className="site-form-grid">
          <label>Title (English)<input name="title_en" required maxLength={200} defaultValue={editing?.title_en ?? EMPTY_ARTICLE.title_en} /></label>
          <label>Título (português)<input name="title_pt" required maxLength={200} defaultValue={editing?.title_pt ?? EMPTY_ARTICLE.title_pt} /></label>
          <label>Summary (English)<textarea name="summary_en" rows={3} maxLength={500} defaultValue={editing?.summary_en ?? EMPTY_ARTICLE.summary_en} /></label>
          <label>Resumo (português)<textarea name="summary_pt" rows={3} maxLength={500} defaultValue={editing?.summary_pt ?? EMPTY_ARTICLE.summary_pt} /></label>
          <label>Article (English)<textarea name="body_en" rows={7} required maxLength={30000} defaultValue={editing?.body_en ?? EMPTY_ARTICLE.body_en} /></label>
          <label>Artigo (português)<textarea name="body_pt" rows={7} required maxLength={30000} defaultValue={editing?.body_pt ?? EMPTY_ARTICLE.body_pt} /></label>
        </div>
        <label className="checkbox-label">
          <input name="is_published" type="checkbox" defaultChecked={editing?.is_published ?? true} />
          {t ? 'Publicar agora' : 'Publish now'}
        </label>
        <p className="form-hint">
          {t
            ? 'A data de publicação será preenchida automaticamente.'
            : 'The publication date is set automatically.'}
        </p>
        {error ? <p className="site-error" role="alert">{error}</p> : null}
        <div className="form-actions">
          <button className="site-button" type="submit" disabled={busy}>
            {busy ? (t ? 'Salvando…' : 'Saving…') : (t ? 'Salvar notícia' : 'Save news')}
          </button>
          {editing ? (
            <button type="button" className="site-text-button" onClick={(event) => cancelEdit(event.currentTarget.form)}>
              {t ? 'Cancelar' : 'Cancel'}
            </button>
          ) : null}
        </div>
      </form>
      <div className="admin-list">
        <h2>{t ? 'Notícias cadastradas' : 'News articles'}</h2>
        {loading ? <p>{t ? 'Carregando…' : 'Loading…'}</p> : null}
        {articles.map((article) => (
          <article className="admin-list-card" key={article.id}>
            <div>
              <strong>{article.title_en}</strong>
              <time>{formatDate(article.published_at, locale)}</time>
              <span className={article.is_published ? 'status-pill status-live' : 'status-pill'}>
                {article.is_published ? (t ? 'Publicada' : 'Published') : (t ? 'Rascunho' : 'Draft')}
              </span>
            </div>
            <div className="admin-actions">
              <button type="button" className="site-text-button" onClick={() => setEditing(article)}>
                {t ? 'Editar' : 'Edit'}
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

const JobsAdmin = ({ locale }: { locale: SiteLocale }) => {
  const user = useAuth((state) => state.user)
  const [jobs, setJobs] = useState<Job[]>([])
  const [editing, setEditing] = useState<Job | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const t = locale === 'pt'

  const load = async () => {
    setLoading(true)
    const { data, error: requestError } = await getSupabaseClient()
      .from('jobs')
      .select('*')
      .order('created_at', { ascending: false })
    if (requestError) {
      setError(requestError.message)
    } else {
      setJobs((data ?? []) as Job[])
      setError('')
    }
    setLoading(false)
  }

  useEffect(() => {
    void load()
  }, [])

  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (busy) {
      return
    }
    setBusy(true)
    setError('')
    const formElement = event.currentTarget
    const form = new FormData(formElement)
    const values = {
      title: formValue(form, 'title'),
      department: formValue(form, 'department'),
      location: formValue(form, 'location'),
      employment_type: formValue(form, 'employment_type'),
      description: formValue(form, 'description'),
      is_active: form.get('is_active') === 'on',
    }
    const query = editing
      ? getSupabaseClient().from('jobs').update(values).eq('id', editing.id)
      : getSupabaseClient().from('jobs').insert({ ...values, created_by: user?.id ?? null })
    const { error: requestError } = await query
    if (requestError) {
      setError(requestError.message)
      setBusy(false)
      return
    }
    setEditing(null)
    formElement.reset()
    setBusy(false)
    await load()
  }

  return (
    <div className="admin-grid">
      <form key={editing?.id ?? 'new-job'} className="admin-form" onSubmit={(event) => void save(event)}>
        <h2>{editing ? (t ? 'Editar vaga' : 'Edit job') : (t ? 'Nova vaga' : 'New job')}</h2>
        <div className="site-form-grid">
          <label>Job title<input name="title" required maxLength={200} defaultValue={editing?.title ?? EMPTY_JOB.title} /></label>
          <label>Department<input name="department" maxLength={120} defaultValue={editing?.department ?? EMPTY_JOB.department} /></label>
          <label>Location<input name="location" required maxLength={160} placeholder="Remote / City, Country" defaultValue={editing?.location ?? EMPTY_JOB.location} /></label>
          <label>Employment type<input name="employment_type" required maxLength={80} defaultValue={editing?.employment_type ?? EMPTY_JOB.employment_type} /></label>
          <label className="form-span">Job description<textarea name="description" rows={7} required maxLength={15000} defaultValue={editing?.description ?? EMPTY_JOB.description} /></label>
        </div>
        <label className="checkbox-label">
          <input name="is_active" type="checkbox" defaultChecked={editing?.is_active ?? true} />
          {t ? 'Vaga aberta para candidaturas' : 'Open for applications'}
        </label>
        {error ? <p className="site-error" role="alert">{error}</p> : null}
        <div className="form-actions">
          <button className="site-button" type="submit" disabled={busy}>
            {busy ? (t ? 'Salvando…' : 'Saving…') : (t ? 'Salvar vaga' : 'Save job')}
          </button>
          {editing ? (
            <button type="button" className="site-text-button" onClick={(event) => { setEditing(null); event.currentTarget.form?.reset() }}>
              {t ? 'Cancelar' : 'Cancel'}
            </button>
          ) : null}
        </div>
      </form>
      <div className="admin-list">
        <h2>{t ? 'Vagas cadastradas' : 'Job listings'}</h2>
        {loading ? <p>{t ? 'Carregando…' : 'Loading…'}</p> : null}
        {jobs.map((job) => (
          <article className="admin-list-card" key={job.id}>
            <div>
              <strong>{job.title}</strong>
              <time>{job.location}</time>
              <span className={job.is_active ? 'status-pill status-live' : 'status-pill'}>
                {job.is_active ? (t ? 'Aberta' : 'Open') : (t ? 'Fechada' : 'Closed')}
              </span>
            </div>
            <div className="admin-actions">
              <button type="button" className="site-text-button" onClick={() => setEditing(job)}>
                {t ? 'Editar' : 'Edit'}
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

const ApplicationsAdmin = ({ locale }: { locale: SiteLocale }) => {
  const [applications, setApplications] = useState<Application[]>([])
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const t = locale === 'pt'

  const load = async () => {
    setLoading(true)
    const [applicationResult, jobResult] = await Promise.all([
      getSupabaseClient().from('job_applications').select('*').order('created_at', { ascending: false }),
      getSupabaseClient().from('jobs').select('id,title'),
    ])
    if (applicationResult.error || jobResult.error) {
      setError(applicationResult.error?.message ?? jobResult.error?.message ?? 'Unable to load applications.')
    } else {
      setApplications((applicationResult.data ?? []) as Application[])
      setJobs((jobResult.data ?? []) as Job[])
      setError('')
    }
    setLoading(false)
  }

  useEffect(() => {
    void load()
  }, [])

  const updateStatus = async (id: string, status: ApplicationStatus) => {
    const accessToken = getAccessToken()
    if (!accessToken) {
      setError(t ? 'Sua sessão expirou. Entre novamente.' : 'Your session expired. Please sign in again.')
      return
    }
    setUpdatingId(id)
    setError('')
    try {
      const response = await fetch('/api/admin/application-status', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id, status }),
      })
      const result = await response.json() as {
        error?: string
        status?: ApplicationStatus
        statusUpdated?: boolean
        emailSent?: boolean
        emailSentAt?: string | null
      }
      if (response.ok || result.statusUpdated) {
        setApplications((items) => items.map((item) => item.id === id
          ? {
              ...item,
              status: result.status ?? status,
              decision_email_sent_at: result.emailSentAt ?? (result.emailSent ? new Date().toISOString() : null),
            }
          : item))
      }
      if (!response.ok) {
        setError(result.error ?? (t ? 'Não foi possível atualizar a candidatura.' : 'Unable to update the application.'))
      }
    } catch (requestError) {
      setError(requestError instanceof Error
        ? requestError.message
        : (t ? 'Não foi possível atualizar a candidatura.' : 'Unable to update the application.'))
    } finally {
      setUpdatingId(null)
    }
  }

  const jobNames = new Map(jobs.map((job) => [job.id, job.title]))
  const statusLabels: Record<ApplicationStatus, string> = t
    ? { new: 'Nova', reviewing: 'Em análise', interview: 'Entrevista', hired: 'Contratada', rejected: 'Recusada' }
    : { new: 'New', reviewing: 'Reviewing', interview: 'Interview', hired: 'Hired', rejected: 'Rejected' }

  return (
    <div className="admin-list application-list">
      <h2>{t ? 'Candidaturas recebidas' : 'Received applications'}</h2>
      {loading ? <p>{t ? 'Carregando…' : 'Loading…'}</p> : null}
      {error ? <p className="site-error" role="alert">{error}</p> : null}
      {!loading && !error && applications.length === 0 ? (
        <p className="site-empty">{t ? 'Nenhuma candidatura ainda.' : 'No applications yet.'}</p>
      ) : null}
      {applications.map((application) => (
        <article className="application-card" key={application.id}>
          <div className="application-heading">
            <div>
              <h3>{application.full_name}</h3>
              <p>{jobNames.get(application.job_id) ?? (t ? 'Vaga removida' : 'Job removed')} · {formatDate(application.created_at, locale)}</p>
            </div>
            <select
              aria-label={t ? `Status de ${application.full_name}` : `Status for ${application.full_name}`}
              value={application.status}
              disabled={updatingId === application.id}
              onChange={(event) => void updateStatus(application.id, event.target.value as ApplicationStatus)}
            >
              {(Object.keys(statusLabels) as ApplicationStatus[]).map((status) => (
                <option key={status} value={status}>{statusLabels[status]}</option>
              ))}
            </select>
          </div>
          {application.status === 'hired' || application.status === 'rejected' ? (
            <p className="application-email-status">
              {application.decision_email_sent_at
                ? (t ? 'E-mail de decisão enviado.' : 'Decision email sent.')
                : (
                    <button
                      type="button"
                      className="site-text-button"
                      disabled={updatingId === application.id}
                      onClick={() => void updateStatus(application.id, application.status)}
                    >
                      {updatingId === application.id
                        ? (t ? 'Enviando…' : 'Sending…')
                        : (t ? 'Enviar / tentar novamente o e-mail' : 'Send / retry decision email')}
                    </button>
                  )}
            </p>
          ) : null}
          <div className="applicant-links">
            <a href={`mailto:${encodeURIComponent(application.email)}`}>{application.email}</a>
            {application.phone ? <a href={`tel:${encodeURIComponent(application.phone)}`}>{application.phone}</a> : null}
            {application.linkedin_url ? <a href={application.linkedin_url} target="_blank" rel="noreferrer">LinkedIn</a> : null}
            {application.resume_url ? <a href={application.resume_url} target="_blank" rel="noreferrer">Resume / portfolio</a> : null}
          </div>
          {application.cover_letter ? <p className="application-letter">{application.cover_letter}</p> : null}
        </article>
      ))}
    </div>
  )
}
