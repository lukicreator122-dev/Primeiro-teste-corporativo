import { useEffect, useState } from 'react'
import { getSupabaseClient } from '../services/supabase.js'
import type { SiteLocale } from './SiteApp.js'

type NewsArticle = {
  id: string
  title_en: string
  title_pt: string
  summary_en: string
  summary_pt: string
  body_en: string
  body_pt: string
  published_at: string
}

export const NewsPage = ({ locale }: { locale: SiteLocale }) => {
  const [articles, setArticles] = useState<NewsArticle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    void getSupabaseClient()
      .from('news_articles')
      .select('id,title_en,title_pt,summary_en,summary_pt,body_en,body_pt,published_at')
      .eq('is_published', true)
      .order('published_at', { ascending: false })
      .then(({ data, error: requestError }) => {
        if (!active) {
          return
        }
        if (requestError) {
          setError(requestError.message)
        } else {
          setArticles((data ?? []) as NewsArticle[])
        }
        setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  const portuguese = locale === 'pt'
  return (
    <section className="site-content">
      <p className="site-eyebrow">Sharko</p>
      <h1>{portuguese ? 'Notícias e atualizações' : 'Research & News'}</h1>
      <p className="site-intro">
        {portuguese
          ? 'Novidades, pesquisas e anúncios da Sharko.'
          : 'Research, product updates, and announcements from Sharko.'}
      </p>
      {loading ? <p className="site-state">{portuguese ? 'Carregando…' : 'Loading…'}</p> : null}
      {error ? <p className="site-error" role="alert">{error}</p> : null}
      {!loading && !error && articles.length === 0 ? (
        <p className="site-empty">
          {portuguese ? 'Ainda não há notícias publicadas.' : 'No news has been published yet.'}
        </p>
      ) : null}
      <div className="news-list">
        {articles.map((article) => {
          const title = portuguese ? article.title_pt : article.title_en
          const summary = portuguese ? article.summary_pt : article.summary_en
          const body = portuguese ? article.body_pt : article.body_en
          return (
            <article className="news-card" key={article.id}>
              <time dateTime={article.published_at}>
                {new Intl.DateTimeFormat(portuguese ? 'pt-BR' : 'en-US', {
                  dateStyle: 'long',
                }).format(new Date(article.published_at))}
              </time>
              <h2>{title}</h2>
              {summary ? <p>{summary}</p> : null}
              <details>
                <summary>{portuguese ? 'Leia mais' : 'Read more'}</summary>
                <div className="news-body">{body}</div>
              </details>
            </article>
          )
        })}
      </div>
    </section>
  )
}
