import { useEffect, useRef, useState, type FormEvent } from 'react'
import {
  sendPasswordReset,
  signIn,
  signInWithGoogle,
  signUp,
  useAuth,
} from '../../services/auth.js'
import sharkoLogo from '../../assets/sharko-logo.png'
import styles from './AuthScreen.module.css'

export const AuthScreen = () => {
  const config = useAuth((state) => state.config)
  const authError = useAuth((state) => state.error)
  const emailInput = useRef<HTMLInputElement>(null)
  const confirmPasswordInput = useRef<HTMLInputElement>(null)
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [socialBusy, setSocialBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  useEffect(() => {
    const previousLanguage = document.documentElement.lang
    document.documentElement.lang = 'en'
    return () => {
      document.documentElement.lang = previousLanguage
    }
  }, [])

  const validateEmail = () => {
    if (!email.trim()) {
      setError('Enter your email address.')
      return false
    }
    if (!emailInput.current?.validity.valid) {
      setError('Enter a valid email address.')
      return false
    }
    return true
  }

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (busy || socialBusy) {
      return
    }
    setError('')
    setNotice('')
    if (!validateEmail()) {
      return
    }
    if (!password) {
      setError('Enter your password.')
      return
    }
    if (mode === 'signup' && password.length < 6) {
      setError('Your password must be at least 6 characters long.')
      return
    }
    if (mode === 'signup' && password !== confirmPassword) {
      setError('Passwords do not match.')
      confirmPasswordInput.current?.focus()
      return
    }

    setBusy(true)
    try {
      if (mode === 'login') {
        await signIn(email.trim(), password)
      } else {
        const signedIn = await signUp(email.trim(), password)
        if (!signedIn) {
          setNotice('If this email can be registered, check your inbox and spam folder for a confirmation link. If you already have an account, sign in or reset your password.')
        }
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Unable to sign in.')
    } finally {
      setBusy(false)
    }
  }

  const resetPassword = async () => {
    setError('')
    setNotice('')
    if (!validateEmail()) {
      return
    }
    setBusy(true)
    try {
      await sendPasswordReset(email.trim())
      setNotice('If an account exists for this email, you will receive instructions to reset your password.')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Unable to send a password reset email.')
    } finally {
      setBusy(false)
    }
  }

  const startGoogleLogin = async () => {
    if (busy || socialBusy) {
      return
    }
    setError('')
    setNotice('')
    setSocialBusy(true)
    try {
      await signInWithGoogle()
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Unable to start Google sign-in.')
      setSocialBusy(false)
    }
  }

  const changeMode = (nextMode: 'login' | 'signup') => {
    setMode(nextMode)
    setConfirmPassword('')
    setError('')
    setNotice('')
  }

  return (
    <main className={styles.page}>
      <section className={styles.panel} aria-labelledby="auth-title">
        <h1 className={styles.title} id="auth-title">
          <img src={sharkoLogo} alt="Sharko" />
        </h1>
        {!config?.configured ? (
          <p className={styles.error} role="alert">
            Supabase is not configured. Add SUPABASE_URL and SUPABASE_ANON_KEY to the server environment.
          </p>
        ) : (
          <>
            <p className={styles.intro}>
              {mode === 'signup'
                ? 'Create a Sharko account with your email to access your AI assistant.'
                : 'Sign in to Sharko with your email or Google account.'}
            </p>
            <form className={styles.form} noValidate onSubmit={(event) => void submit(event)}>
              <input
                ref={emailInput}
                type="email"
                autoComplete="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="Email address"
                aria-label="Email address"
                required
              />
              <div className={styles.passwordField}>
                <input
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="Password"
                  aria-label="Password"
                  required
                />
                <button
                  className={styles.visibilityToggle}
                  type="button"
                  onClick={() => setShowPassword((visible) => !visible)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  aria-pressed={showPassword}
                >
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
              {mode === 'signup' ? (
                <input
                  ref={confirmPasswordInput}
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                  placeholder="Confirm password"
                  aria-label="Confirm password"
                  required
                />
              ) : null}

              {error || authError ? <p className={styles.error} role="alert">{error || authError}</p> : null}
              {notice ? <p className={styles.notice} role="status">{notice}</p> : null}

              <p className={styles.legal}>
                By signing up or signing in, you agree to Sharko’s <span>Terms of Use</span> and <span>Privacy Policy</span>.
              </p>

              <div className={styles.links}>
                <button className={styles.textLink} type="button" onClick={() => void resetPassword()} disabled={busy || socialBusy}>
                  Forgot password?
                </button>
                <button
                  className={styles.textLink}
                  type="button"
                  onClick={() => changeMode(mode === 'login' ? 'signup' : 'login')}
                  disabled={busy || socialBusy}
                >
                  {mode === 'login' ? 'Sign up' : 'Sign in'}
                </button>
              </div>

              <button className={styles.primary} type="submit" disabled={busy || socialBusy}>
                {busy ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'}
              </button>
            </form>

            <div className={styles.socialLinks}>
              <button type="button" disabled={busy || socialBusy} onClick={() => void startGoogleLogin()}>
                {socialBusy ? 'Connecting to Google...' : 'Continue with Google'}
              </button>
            </div>
          </>
        )}
      </section>
      <footer className={styles.footer}>
        © 2026 Sharko <span aria-hidden="true">·</span> Contact us
      </footer>
    </main>
  )
}
