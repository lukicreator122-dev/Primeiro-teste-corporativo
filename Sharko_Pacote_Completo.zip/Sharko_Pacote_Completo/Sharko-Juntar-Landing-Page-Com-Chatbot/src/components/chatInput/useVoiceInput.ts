import { useCallback, useEffect, useRef, useState } from 'react'
import { showToast } from '../base/toastState.js'

export type VoiceInputStatus = 'idle' | 'recording' | 'transcribing'
type SpeechResult = { isFinal: boolean; 0: { transcript: string } }
type SpeechEvent = { resultIndex: number; results: ArrayLike<SpeechResult> }
type SpeechRecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  onresult: ((event: SpeechEvent) => void) | null
  onerror: (() => void) | null
  onend: (() => void) | null
  start(): void
  stop(): void
  abort(): void
}
type SpeechRecognitionConstructor = new () => SpeechRecognitionLike

const getSpeechRecognition = (): SpeechRecognitionConstructor | null => {
  if (typeof window === 'undefined') return null
  const browser = window as Window & { SpeechRecognition?: SpeechRecognitionConstructor; webkitSpeechRecognition?: SpeechRecognitionConstructor }
  return browser.SpeechRecognition || browser.webkitSpeechRecognition || null
}
const AVAILABLE = getSpeechRecognition() !== null

/** Usa o reconhecimento de voz nativo do navegador; não depende de uma API de transcrição externa. */
export const useVoiceInput = (onText: (text: string) => void) => {
  const [status, setStatus] = useState<VoiceInputStatus>('idle')
  const [seconds, setSeconds] = useState(0)
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)
  const transcriptRef = useRef('')
  const cancelledRef = useRef(false)
  const onTextRef = useRef(onText)
  onTextRef.current = onText

  const cancel = useCallback(() => {
    cancelledRef.current = true
    recognitionRef.current?.abort()
    recognitionRef.current = null
    transcriptRef.current = ''
    setStatus('idle')
    setSeconds(0)
  }, [])

  const toggle = useCallback(() => {
    if (status === 'recording') {
      setStatus('transcribing')
      recognitionRef.current?.stop()
      return
    }
    if (status === 'transcribing') {
      cancel()
      return
    }
    const Constructor = getSpeechRecognition()
    if (!Constructor) {
      showToast({ key: 'voiceInputFailed' })
      return
    }
    cancelledRef.current = false
    transcriptRef.current = ''
    const recognition = new Constructor()
    recognition.lang = navigator.language || 'pt-BR'
    recognition.continuous = true
    recognition.interimResults = false
    recognition.onresult = (event) => {
      for (let index = event.resultIndex; index < event.results.length; index++) {
        const result = event.results[index]
        if (result?.isFinal) transcriptRef.current += `${result[0]?.transcript || ''} `
      }
    }
    recognition.onerror = () => {
      if (!cancelledRef.current) showToast({ key: 'voiceInputFailed' })
      cancelledRef.current = true
      setStatus('idle')
    }
    recognition.onend = () => {
      const transcript = transcriptRef.current.trim()
      recognitionRef.current = null
      setStatus('idle')
      setSeconds(0)
      if (!cancelledRef.current && transcript) onTextRef.current(transcript)
      else if (!cancelledRef.current) showToast({ key: 'voiceInputEmpty' })
    }
    recognitionRef.current = recognition
    setStatus('recording')
    try { recognition.start() } catch { recognitionRef.current = null; setStatus('idle'); showToast({ key: 'voiceInputFailed' }) }
  }, [status, cancel])

  useEffect(() => {
    if (status !== 'recording') return
    const startedAt = Date.now()
    const timer = setInterval(() => setSeconds(Math.floor((Date.now() - startedAt) / 1000)), 500)
    return () => clearInterval(timer)
  }, [status])
  useEffect(() => cancel, [cancel])

  const getAnalyser = useCallback(() => null, [])
  return { status, seconds, getAnalyser, toggle, cancel, available: AVAILABLE }
}
