import { createRoot } from 'react-dom/client'
import { App } from './app/App.js'
import { SiteApp } from './site/SiteApp.js'
import { setupTheme } from './app/theme.js'
import { ensureKatex } from './services/markdown/katex.js'
import './app/theme.css'
import './app/global.css'

ensureKatex()
setupTheme()

const pathname = window.location.pathname.replace(/\/+$/, '') || '/'
const sitePage = ['/admin', '/careers', '/research-news', '/careers.html', '/research-news.html'].includes(pathname)

createRoot(document.getElementById('root') as HTMLElement).render(sitePage ? <SiteApp /> : <App />)
