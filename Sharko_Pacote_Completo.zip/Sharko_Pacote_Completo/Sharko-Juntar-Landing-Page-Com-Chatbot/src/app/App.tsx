import { useEffect, useState } from 'react'
import { useTranslate } from '../i18n/index.js'
import { useSettings } from '../services/settings.js'
import { useIsMobile, useMobileViewport, usePreventPageScroll } from './viewport.js'
import {
  bindChatPersistence,
  initChat,
  retrySaveSessions,
  sendMessage,
  selectSession,
  useChatStore,
} from '../services/chat/store.js'
import { setDraftText } from '../services/chat/drafts.js'
import { SearchPanel } from '../components/search/SearchPanel.js'
import { closeSearchPanel } from '../components/search/searchPanelState.js'
import { SessionView } from '../components/session/SessionView.js'
import { MobileHeader } from '../components/session/MobileHeader.js'
import { Welcome } from '../components/session/Welcome.js'
import { AuthScreen } from '../components/auth/AuthScreen.js'
import { initAuth, signOut, useAuth } from '../services/auth.js'
import { setActiveUserId } from '../services/chat/db.js'
import { SettingsDialog } from '../components/settings/SettingsDialog.js'
import { Toast } from '../components/base/Toast.js'
import { showToast } from '../components/base/toastState.js'
import { onUploadNotice } from '../services/attachments.js'
import { Button } from '../components/base/Button.js'
import { stopReadAloud } from '../services/speech/readAloud.js'
import { CollapsedSider } from '../components/sider/CollapsedSider.js'
import { closeMobileSider } from '../components/sider/mobileSiderState.js'
import { MobileSider, Sider } from '../components/sider/Sider.js'
import styles from './App.module.css'

const PENDING_PROMPT_KEY = 'sharko:pending-prompt'

export const App = () => {
  const t = useTranslate()
  const authReady = useAuth((state) => state.ready)
  const authUser = useAuth((state) => state.user)
  const authDisabled = useAuth((state) => state.config?.authDisabled ?? false)
  const [authActionError, setAuthActionError] = useState('')
  const isMobile = useIsMobile()
  const locale = useSettings((state) => state.locale)
  // 移动端侧边栏以独立抽屉管理开合状态
  const siderCollapsed = useSettings((state) => state.siderCollapsed) && !isMobile
  const ready = useChatStore((state) => state.ready)
  const initError = useChatStore((state) => state.initError)
  const saveError = useChatStore((state) => Object.values(state.sessionSaveErrors).some(Boolean))
  const importingHistory = useChatStore((state) => state.importingHistory)
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null)
  const session = useChatStore((state) =>
    state.activeId !== null && Object.hasOwn(state.sessionCache, state.activeId)
      ? state.sessionCache[state.activeId]
      : undefined
  )
  const sessionLoadError = useChatStore((state) =>
    state.activeId === null ? false : state.sessionLoadErrors[state.activeId] === true
  )
  const frameRef = useMobileViewport(isMobile)
  const streaming = useChatStore((state) =>
    state.activeId === null ? false : Object.hasOwn(state.streaming, state.activeId)
  )
  const activeId = useChatStore((state) => state.activeId)
  const metadata = authUser?.user_metadata
  const profileName =
    (typeof metadata?.full_name === 'string' && metadata.full_name) ||
    (typeof metadata?.name === 'string' && metadata.name) ||
    authUser?.email ||
    ''
  const profileAvatar =
    (typeof metadata?.avatar_url === 'string' && metadata.avatar_url) ||
    (typeof metadata?.picture === 'string' && metadata.picture) ||
    ''

  usePreventPageScroll(isMobile)

  useEffect(() => {
    document.documentElement.lang = locale
  }, [locale])

  // 文件数、存储空间达到上限时，附件上只显示「上传失败」，原因用 toast 说明
  useEffect(() => onUploadNotice(showToast), [])
  useEffect(bindChatPersistence, [])

  // 搜索结果面板只属于当前会话
  useEffect(closeSearchPanel, [activeId])
  // 切换会话时停止朗读
  useEffect(stopReadAloud, [activeId])
  // 移动端选中会话、切换布局后收起抽屉
  useEffect(closeMobileSider, [activeId, isMobile])

  useEffect(() => { void initAuth() }, [])

  useEffect(() => {
    const url = new URL(window.location.href)
    const urlPrompt = url.searchParams.get('prompt')?.trim()
    const savedPrompt = sessionStorage.getItem(PENDING_PROMPT_KEY)?.trim()
    const prompt = urlPrompt || savedPrompt
    if (!prompt) {
      return
    }
    if (urlPrompt) {
      sessionStorage.setItem(PENDING_PROMPT_KEY, urlPrompt)
      url.searchParams.delete('prompt')
      window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`)
    }
    setPendingPrompt(prompt)
  }, [])

  useEffect(() => {
    if (!authUser && !authDisabled) {
      return
    }
    setActiveUserId(authUser?.id ?? 'local')
    void initChat()
  }, [authUser, authDisabled])

  useEffect(() => {
    if (!pendingPrompt || !ready || importingHistory || (!authUser && !authDisabled)) {
      return
    }
    setDraftText(null, pendingPrompt)
    if (sendMessage(null)) {
      sessionStorage.removeItem(PENDING_PROMPT_KEY)
      setPendingPrompt(null)
    }
  }, [authUser, authDisabled, importingHistory, pendingPrompt, ready])

  if (!authReady) return <div className={styles.loadingView}><div className={styles.loadingState}>Carregando Sharko...</div></div>
  if (!authUser && !authDisabled) return <AuthScreen />

  return (
    <>
      <div ref={frameRef} className={styles.frame}>
        {isMobile ? <MobileSider /> : siderCollapsed ? null : <Sider />}
        <main className={styles.main}>
          {authUser ? (
            <div className={styles.accountProfile}>
              {profileAvatar ? (
                <img className={styles.accountAvatar} src={profileAvatar} alt="" referrerPolicy="no-referrer" />
              ) : (
                <span className={styles.accountAvatarFallback} aria-hidden="true">
                  {profileName.charAt(0).toUpperCase()}
                </span>
              )}
              <div className={styles.accountDetails}>
                <span className={styles.accountName}>{profileName}</span>
                {authUser.email ? <span className={styles.accountEmail}>{authUser.email}</span> : null}
              </div>
              <button
                type="button"
                className={styles.signOut}
                onClick={() => {
                  setAuthActionError('')
                  void signOut().catch((error: unknown) => {
                    setAuthActionError(error instanceof Error ? error.message : 'Unable to sign out.')
                  })
                }}
              >
                Sign out
              </button>
            </div>
          ) : null}
          {authActionError ? <div className={styles.authActionError} role="alert">{authActionError}</div> : null}
          {saveError ? (
            <div className={styles.saveError} role="alert">
              <span>{t('sessionSaveFailed')}</span>
              <Button
                variant="outlined"
                size="s"
                disabled={importingHistory}
                onClick={retrySaveSessions}
              >
                {t('retry')}
              </Button>
            </div>
          ) : null}
          <div className={styles.content}>
            {siderCollapsed ? <CollapsedSider /> : null}
            {!ready || (activeId !== null && !session) ? (
              <div className={styles.loadingView}>
                {isMobile ? <MobileHeader /> : null}
                <div className={styles.loadingState} role="status" aria-live="polite">
                  <span>
                    {(!ready ? initError : sessionLoadError)
                      ? t(!ready ? 'sessionListLoadFailed' : 'sessionLoadFailed')
                      : t('sessionLoading')}
                  </span>
                  {(!ready ? initError : sessionLoadError) ? (
                    <Button
                      variant="outlined"
                      size="m"
                      onClick={() => {
                        if (!ready) {
                          void initChat()
                        } else if (activeId !== null) {
                          selectSession(activeId)
                        }
                      }}
                    >
                      {t('retry')}
                    </Button>
                  ) : null}
                </div>
              </div>
            ) : session ? (
              <SessionView
                session={session}
                streaming={streaming}
                siderCollapsed={siderCollapsed}
              />
            ) : (
              <Welcome />
            )}
          </div>
        </main>
        <SearchPanel />
      </div>
      <SettingsDialog />
      <Toast />
    </>
  )
}
