import { create } from 'zustand'
import type { Session, User } from '@supabase/supabase-js'
import { configureSupabase, getSupabaseClient } from './supabase.js'

type SupabaseConfig = {
  supabaseUrl: string
  supabaseAnonKey: string
  configured: boolean
  authDisabled?: boolean
}
type AuthState = {
  ready: boolean
  config: SupabaseConfig | null
  user: User | null
  accessToken: string | null
  error: string | null
}

const LEGACY_TOKEN_KEY = 'aetel:supabase:access-token'
const LEGACY_REFRESH_KEY = 'aetel:supabase:refresh-token'
export const useAuth = create<AuthState>(() => ({
  ready: false,
  config: null,
  user: null,
  accessToken: null,
  error: null,
}))

let initialization: Promise<void> | null = null

const authRedirectUrl = () =>
  new URL(window.location.pathname === '/admin' ? '/admin' : '/chat', window.location.origin).toString()

const updateSession = (session: Session | null) => {
  useAuth.setState({
    accessToken: session?.access_token ?? null,
    user: session?.user ?? null,
    error: null,
  })
}

const initializeAuth = async () => {
  try {
    const response = await fetch('/api/config', { cache: 'no-store' })
    if (!response.ok) {
      throw new Error(`Unable to load authentication configuration (${response.status}).`)
    }
    const config = (await response.json()) as SupabaseConfig
    useAuth.setState({ config })

    if (config.authDisabled) {
      useAuth.setState({ ready: true, user: null, accessToken: null, error: null })
      return
    }
    if (!config.configured) {
      useAuth.setState({ ready: true })
      return
    }

    const client = configureSupabase(config.supabaseUrl, config.supabaseAnonKey)
    client.auth.onAuthStateChange((_event, session) => updateSession(session))

    const { data, error } = await client.auth.getSession()
    if (error) {
      throw error
    }

    let session = data.session
    let migrationError: string | null = null
    if (!session) {
      const accessToken = localStorage.getItem(LEGACY_TOKEN_KEY)
      const refreshToken = localStorage.getItem(LEGACY_REFRESH_KEY)
      if (accessToken && refreshToken) {
        const restored = await client.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        })
        if (restored.error) {
          migrationError = 'Your saved session could not be restored. Please sign in again.'
        } else {
          session = restored.data.session
        }
      }
    }

    localStorage.removeItem(LEGACY_TOKEN_KEY)
    localStorage.removeItem(LEGACY_REFRESH_KEY)
    updateSession(session)
    useAuth.setState({ ready: true, error: migrationError })
  } catch (error) {
    useAuth.setState({
      ready: true,
      error: error instanceof Error ? error.message : 'Unable to initialize authentication.',
    })
  }
}

export const getAccessToken = () => useAuth.getState().accessToken

export const initAuth = () => (initialization ??= initializeAuth())

export async function signIn(email: string, password: string) {
  const { data, error } = await getSupabaseClient().auth.signInWithPassword({ email, password })
  if (error) {
    throw error
  }
  updateSession(data.session)
}

export async function signUp(email: string, password: string): Promise<boolean> {
  const { data, error } = await getSupabaseClient().auth.signUp({
    email,
    password,
    options: { emailRedirectTo: authRedirectUrl() },
  })
  if (error) {
    throw error
  }
  if (data.session) {
    updateSession(data.session)
  }
  return Boolean(data.session)
}

async function signInWithGoogleProvider() {
  const { error } = await getSupabaseClient().auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: authRedirectUrl() },
  })
  if (error) {
    throw error
  }
}

export const signInWithGoogle = () => signInWithGoogleProvider()

export async function sendPasswordReset(email: string) {
  const { error } = await getSupabaseClient().auth.resetPasswordForEmail(email, {
    redirectTo: authRedirectUrl(),
  })
  if (error) {
    throw error
  }
}

export async function signOut() {
  const { error } = await getSupabaseClient().auth.signOut()
  if (error) {
    throw error
  }
  window.location.reload()
}
