import { create } from 'zustand'
import type { TranslationMessage } from '../../i18n/index.js'

export type ReadAloudStatus = 'idle' | 'loading' | 'playing'
type ReadAloudState = { messageId: string | null; status: ReadAloudStatus }
export const useReadAloud = create<ReadAloudState>(() => ({ messageId: null, status: 'idle' }))
let current: SpeechSynthesisUtterance | null = null

const finish = (utterance: SpeechSynthesisUtterance) => {
  if (current !== utterance) return
  current = null
  useReadAloud.setState({ messageId: null, status: 'idle' })
}

export const stopReadAloud = () => {
  if (current) {
    window.speechSynthesis.cancel()
    current = null
    useReadAloud.setState({ messageId: null, status: 'idle' })
  }
}

export const describeReadAloudError = (_error: unknown): TranslationMessage | string =>
  'Não foi possível reproduzir a leitura de voz neste navegador.'

/** Lê a resposta usando a voz nativa do navegador, sem consumir créditos de API. */
export const toggleReadAloud = (
  messageId: string,
  text: string,
  onError: (error: unknown) => void
) => {
  const reading = useReadAloud.getState().messageId
  stopReadAloud()
  if (reading === messageId) return
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onError(new Error('Speech synthesis indisponível'))
    return
  }
  const utterance = new SpeechSynthesisUtterance(text)
  utterance.lang = navigator.language || 'pt-BR'
  utterance.onstart = () => useReadAloud.setState({ messageId, status: 'playing' })
  utterance.onend = () => finish(utterance)
  utterance.onerror = (event) => {
    finish(utterance)
    if (event.error !== 'canceled' && event.error !== 'interrupted') onError(event)
  }
  current = utterance
  useReadAloud.setState({ messageId, status: 'loading' })
  try { window.speechSynthesis.speak(utterance) } catch (error) { finish(utterance); onError(error) }
}
