import { createClient, type SupabaseClient } from '@supabase/supabase-js'

let client: SupabaseClient | null = null

export const configureSupabase = (url: string, publishableKey: string): SupabaseClient => {
  if (!client) {
    client = createClient(url, publishableKey, {
      auth: {
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'pkce',
        persistSession: true,
      },
    })
  }
  return client
}

export const getSupabaseClient = (): SupabaseClient => {
  if (!client) {
    throw new Error('Supabase is not initialized. Check the server configuration.')
  }
  return client
}
