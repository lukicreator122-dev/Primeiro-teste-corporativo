const translations = {
  Research: 'Pesquisa',
  Careers: 'Carreiras',
  Home: 'Início',
  'Research & News': 'Notícias e pesquisa',
  'Terms of Use': 'Termos de uso',
  'Privacy Policy': 'Política de privacidade',
  'Try Sharko AI': 'Experimente a IA Sharko',
  'Into the Unknown': 'Explore o desconhecido',
  DeepThink: 'Pensamento profundo',
  Search: 'Busca',
  'Legal & Security': 'Jurídico e segurança',
  'Join Us': 'Faça parte',
  Admin: 'Administração',
  '© 2026 Sharko. All rights reserved.': `© ${new Date().getFullYear()} Sharko. Todos os direitos reservados.`,
}

const localeKey = 'sharko:site-locale'
const originalText = new Map()
const prompt = document.querySelector('.hero-input')

const mobileMenuButton = document.querySelector('#menu-open')
if (mobileMenuButton && !document.querySelector('[data-site-mobile-locale]')) {
  const controls = document.createElement('div')
  controls.className = 'flex items-center md:hidden'
  controls.dataset.siteMobileLocale = ''
  const toggle = document.createElement('div')
  toggle.className = 'ds-locale-toggle'
  for (const [label, language] of [['PT', 'Português'], ['EN', 'English']]) {
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'ds-locale-toggle-item'
    button.textContent = label
    button.setAttribute('aria-label', language)
    toggle.append(button)
  }
  controls.append(toggle)
  mobileMenuButton.before(controls)
}

const languageButtons = [...document.querySelectorAll('.ds-locale-toggle-item')]

const addAdminLink = (container, className) => {
  if (!container || container.querySelector('[data-site-admin-link]')) {
    return
  }
  const link = document.createElement('a')
  link.href = '/admin'
  link.className = className
  link.dataset.siteAdminLink = ''
  link.textContent = 'Admin'
  const careersLink = container.querySelector('a[href="/careers"]')
  if (careersLink) {
    careersLink.after(link)
  } else {
    container.append(link)
  }
}

addAdminLink(
  document.querySelector('.ds-header-bar > .hidden.md\\:flex'),
  'ds-btn-ghost ds-btn-s ds-btn-nav',
)
addAdminLink(document.querySelector('.ds-mobile-menu-body'), 'ds-mobile-menu-item')

const headerWrapper = document.querySelector('.ds-header-wrapper')
if (headerWrapper) {
  const motionStyle = document.createElement('style')
  motionStyle.textContent = `
    .ds-header-wrapper { transition: transform 280ms cubic-bezier(.22, 1, .36, 1); }
    .ds-header-wrapper.is-scroll-hidden { transform: translateY(calc(-100% - 1rem)); }
    @media (prefers-reduced-motion: reduce) {
      .ds-header-wrapper { transition: none; }
    }
  `
  document.head.append(motionStyle)

  const mobileMenu = document.querySelector('#mobile-menu')
  let previousScrollY = window.scrollY
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY
    if (scrollY < 80 || scrollY < previousScrollY || mobileMenu?.classList.contains('is-open')) {
      headerWrapper.classList.remove('is-scroll-hidden')
    } else if (scrollY > previousScrollY && scrollY > 100) {
      headerWrapper.classList.add('is-scroll-hidden')
    }
    previousScrollY = scrollY
  }, { passive: true })
}

const setLocale = (locale) => {
  const portuguese = locale === 'pt'
  document.documentElement.lang = portuguese ? 'pt-BR' : 'en'

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
  let node
  while ((node = walker.nextNode())) {
    const parent = node.parentElement
    if (!parent || /^(SCRIPT|STYLE)$/.test(parent.tagName) || parent.closest('.ds-toast')) {
      continue
    }
    if (!originalText.has(node)) {
      originalText.set(node, node.nodeValue)
    }
    const original = originalText.get(node)
    const label = original.trim()
    const translated = portuguese ? translations[label] : undefined
    node.nodeValue = translated ? original.replace(label, translated) : original
  }

  if (prompt instanceof HTMLTextAreaElement) {
    prompt.placeholder = portuguese ? 'Pergunte o que quiser, vamos explorar juntos' : 'Ask anything, explore together'
  }
  languageButtons.forEach((button, index) => {
    const option = index % 2
    button.textContent = option === 0 ? 'PT' : 'EN'
    button.classList.toggle('is-active', portuguese ? option === 0 : option === 1)
  })
  localStorage.setItem(localeKey, locale)
}

document.addEventListener(
  'click',
  (event) => {
    const button =
      event.target instanceof Element ? event.target.closest('.ds-locale-toggle-item') : null
    if (!button) {
      return
    }
    event.preventDefault()
    event.stopImmediatePropagation()
    setLocale(button.textContent.trim() === 'PT' ? 'pt' : 'en')
  },
  true
)

const savedLocale = localStorage.getItem(localeKey) === 'pt' ? 'pt' : 'en'
setLocale(savedLocale)
