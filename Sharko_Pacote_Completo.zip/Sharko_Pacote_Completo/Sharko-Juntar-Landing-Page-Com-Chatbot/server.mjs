import http from 'node:http'
import { randomUUID } from 'node:crypto'
import { readFile, stat } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))
const dist = path.join(root, 'dist')

// Optional local .env loader. Production hosts should inject environment variables directly.
try {
  const envText = await readFile(path.join(root, '.env'), 'utf8')
  for (const line of envText.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '')
  }
} catch {}

const port = Number(process.env.PORT || 3000)
const localAuthDisabled = process.env.AETEL_LOCAL_AUTH_DISABLED === 'true' && process.env.NODE_ENV !== 'production'
const supabaseUrl = (process.env.SUPABASE_URL || '').replace(/\/$/, '')
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || ''
const difyBaseUrl = (process.env.DIFY_API_URL || 'https://api.dify.ai/v1').replace(/\/$/, '')
const difyApiKey = process.env.DIFY_API_KEY || ''
const resendApiKey = process.env.RESEND_API_KEY || ''
const resendFromEmail = process.env.RESEND_FROM_EMAIL || ''

const json = (res, status, value) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(JSON.stringify(value))
}

const readBodyBuffer = async (req) => {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  return Buffer.concat(chunks)
}
const readBody = async (req) => (await readBodyBuffer(req)).toString('utf8')

async function authenticate(req) {
  if (localAuthDisabled) return { id: 'local' }
  if (!supabaseUrl || !supabaseAnonKey) throw new Error('Supabase ainda não está configurado no servidor.')
  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ')) throw new Error('Faça login para usar o Sharko.')
  const response = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: supabaseAnonKey, Authorization: auth } })
  if (!response.ok) throw new Error('Sessão inválida ou expirada. Entre novamente.')
  return response.json()
}

async function handleApplicationStatus(req, res) {
  let user
  try { user = await authenticate(req) } catch (error) { return json(res, 401, { error: error.message }) }
  if (user.app_metadata?.role !== 'admin') return json(res, 403, { error: 'Apenas administradores podem atualizar candidaturas.' })

  let payload
  try { payload = JSON.parse(await readBody(req)) } catch { return json(res, 400, { error: 'Corpo da solicitação inválido.' }) }
  const { id, status } = payload
  const validStatuses = ['new', 'reviewing', 'interview', 'hired', 'rejected']
  if (typeof id !== 'string' || !id || !validStatuses.includes(status)) {
    return json(res, 400, { error: 'Candidatura ou status inválido.' })
  }
  const isDecision = status === 'hired' || status === 'rejected'

  const restHeaders = {
    apikey: supabaseAnonKey,
    Authorization: req.headers.authorization,
    'Content-Type': 'application/json',
  }
  const applicationUrl = `${supabaseUrl}/rest/v1/job_applications?id=eq.${encodeURIComponent(id)}`
  const applicationResponse = await fetch(`${applicationUrl}&select=id,job_id,email,full_name,status,updated_at,decision_email_sent_at`, {
    headers: restHeaders,
  })
  if (!applicationResponse.ok) {
    return json(res, 502, { error: `Não foi possível consultar a candidatura: ${(await applicationResponse.text()).slice(0, 1000)}` })
  }
  const applications = await applicationResponse.json()
  const application = applications[0]
  if (!application) return json(res, 404, { error: 'Candidatura não encontrada.' })
  if (isDecision && application.status === status && application.decision_email_sent_at) {
    return json(res, 200, { status, emailSentAt: application.decision_email_sent_at })
  }
  if (isDecision && (!resendApiKey || !resendFromEmail)) {
    return json(res, 503, { error: 'Configure RESEND_API_KEY e RESEND_FROM_EMAIL no servidor antes de enviar e-mails de decisão.' })
  }

  let decisionKey = application.updated_at
  const statusChanged = application.status !== status
  if (statusChanged) {
    const updateResponse = await fetch(applicationUrl, {
      method: 'PATCH',
      headers: { ...restHeaders, Prefer: 'return=representation' },
      body: JSON.stringify({ status, decision_email_sent_at: null }),
    })
    if (!updateResponse.ok) {
      return json(res, 502, { error: `Não foi possível atualizar o status: ${(await updateResponse.text()).slice(0, 1000)}` })
    }
    const updatedApplications = await updateResponse.json()
    decisionKey = updatedApplications[0]?.updated_at || new Date().toISOString()
  }

  if (!isDecision) return json(res, 200, { status, emailSentAt: null })

  const jobResponse = await fetch(
    `${supabaseUrl}/rest/v1/jobs?id=eq.${encodeURIComponent(application.job_id)}&select=title`,
    { headers: restHeaders },
  )
  if (!jobResponse.ok) {
    return json(res, 502, { error: `Status atualizado, mas não foi possível consultar a vaga: ${(await jobResponse.text()).slice(0, 1000)}`, statusUpdated: true, status })
  }
  const jobs = await jobResponse.json()
  const jobTitle = jobs[0]?.title || 'the position'
  const accepted = status === 'hired'
  const subject = accepted
    ? `Good news about your application to ${jobTitle}`
    : `Update on your application to ${jobTitle}`
  const plainText = accepted
    ? `Hi ${application.full_name},\n\nWe are pleased to let you know that we would like to move forward with your application for ${jobTitle}. Our team will contact you with the next steps.\n\nThank you,\nSharko`
    : `Hi ${application.full_name},\n\nThank you for your interest in ${jobTitle} and for taking the time to apply. After careful consideration, we will not be moving forward with your application at this time.\n\nWe appreciate your interest in Sharko and wish you the best in your search.\n\nThank you,\nSharko`
  const safeName = String(application.full_name).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character])
  const safeJobTitle = String(jobTitle).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character])
  const html = accepted
    ? `<p>Hi ${safeName},</p><p>We are pleased to let you know that we would like to move forward with your application for <strong>${safeJobTitle}</strong>. Our team will contact you with the next steps.</p><p>Thank you,<br>Sharko</p>`
    : `<p>Hi ${safeName},</p><p>Thank you for your interest in <strong>${safeJobTitle}</strong> and for taking the time to apply. After careful consideration, we will not be moving forward with your application at this time.</p><p>We appreciate your interest in Sharko and wish you the best in your search.</p><p>Thank you,<br>Sharko</p>`
  const emailResponse = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${resendApiKey}`,
      'Content-Type': 'application/json',
      'Idempotency-Key': `${application.id}-${decisionKey}`,
    },
    body: JSON.stringify({
      from: resendFromEmail,
      to: [application.email],
      subject,
      html,
      text: plainText,
    }),
  })
  if (!emailResponse.ok) {
    const detail = (await emailResponse.text()).slice(0, 1000)
    return json(res, 502, {
      error: `Status atualizado, mas o e-mail não foi enviado: ${detail}`,
      statusUpdated: true,
      status,
    })
  }

  const sentAt = new Date().toISOString()
  const sentResponse = await fetch(applicationUrl, {
    method: 'PATCH',
    headers: { ...restHeaders, Prefer: 'return=minimal' },
    body: JSON.stringify({ decision_email_sent_at: sentAt }),
  })
  if (!sentResponse.ok) {
    return json(res, 502, {
      error: `O e-mail foi enviado, mas não foi possível registrar o envio: ${(await sentResponse.text()).slice(0, 1000)}`,
      statusUpdated: true,
      status,
      emailSent: true,
    })
  }
  return json(res, 200, { status, emailSentAt: sentAt })
}

async function handleDify(req, res) {
  if (!difyApiKey) return json(res, 503, { error: 'DIFY_API_KEY não foi configurada no servidor.' })
  let user
  try { user = await authenticate(req) } catch (error) { return json(res, 401, { error: error.message }) }

  let payload
  try { payload = JSON.parse(await readBody(req)) } catch { return json(res, 400, { error: 'Corpo da solicitação inválido.' }) }
  const messages = Array.isArray(payload.messages) ? payload.messages : []
  const lastUserMessage = [...messages].reverse().find((message) => message.role === 'user')
  const attachedFiles = Array.isArray(lastUserMessage?.content) ? lastUserMessage.content.flatMap((part) => {
    const id = part?.source?.file_id
    if (!id || part?.source?.type !== 'file') return []
    return [{ type: part.type === 'image' ? 'image' : 'document', transfer_method: 'local_file', upload_file_id: id }]
  }) : []
  const transcript = messages.map((message) => {
    const content = typeof message.content === 'string'
      ? message.content
      : Array.isArray(message.content)
        ? message.content.filter((part) => part?.type === 'text').map((part) => part.text || '').join('\n')
        : ''
    return `${message.role === 'assistant' ? 'Sharko' : 'Usuário'}: ${content}`
  }).filter((line) => !line.endsWith(': ')).join('\n\n')
  const query = transcript.trim()
    ? transcript
    : attachedFiles.some((file) => file.type === 'image')
      ? 'Descreva a imagem enviada.'
      : attachedFiles.length > 0
        ? 'Analise o arquivo enviado.'
        : ''
  if (!query) return json(res, 400, { error: 'Digite uma mensagem.' })

  const difyResponse = await fetch(`${difyBaseUrl}/chat-messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${difyApiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      inputs: {},
      query,
      response_mode: 'streaming',
      conversation_id: '',
      user: user.id,
      ...(attachedFiles.length ? { files: attachedFiles } : {}),
    }),
  })
  if (!difyResponse.ok) {
    const detail = await difyResponse.text()
    return json(res, difyResponse.status, { error: `Dify: ${detail.slice(0, 1200)}` })
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  })
  const emit = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
  const messageId = `msg_${randomUUID().replaceAll('-', '')}`
  emit('message_start', { type: 'message_start', message: { id: messageId, type: 'message', role: 'assistant', model: 'aetel-dify', content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 0, output_tokens: 0 } } })
  emit('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } })

  const decoder = new TextDecoder()
  let buffer = ''
  let agentMessageSeen = false
  const forwardTextEvent = (event) => {
    if (event.event === 'agent_message') {
      agentMessageSeen = true
    } else if (event.event !== 'message' || agentMessageSeen) {
      return
    }
    const text = event.answer || event.text || ''
    if (text) {
      emit('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } })
    }
  }
  try {
    for await (const chunk of difyResponse.body) {
      buffer += decoder.decode(chunk, { stream: true })
      const records = buffer.split(/\r?\n\r?\n/)
      buffer = records.pop() || ''
      for (const record of records) {
        const dataLine = record.split(/\r?\n/).find((line) => line.startsWith('data:'))
        if (!dataLine) continue
        let event
        try { event = JSON.parse(dataLine.slice(5).trim()) } catch { continue }
        if (event.event === 'message' || event.event === 'agent_message') {
          forwardTextEvent(event)
        } else if (event.event === 'error') {
          emit('error', { error: { message: event.message || 'Erro retornado pelo Dify.' } })
        }
      }
    }
    if (buffer.trim()) {
      const line = buffer.split(/\r?\n/).find((entry) => entry.startsWith('data:'))
      if (line) {
        try {
          const event = JSON.parse(line.slice(5).trim())
          if (event.event === 'message' || event.event === 'agent_message') {
            forwardTextEvent(event)
          }
        } catch {}
      }
    }
    emit('content_block_stop', { type: 'content_block_stop', index: 0 })
    emit('message_delta', { type: 'message_delta', delta: { stop_reason: 'end_turn', stop_sequence: null }, usage: { output_tokens: 0 } })
    emit('message_stop', { type: 'message_stop' })
  } catch (error) {
    if (!res.destroyed) emit('error', { error: { message: error instanceof Error ? error.message : 'Falha na conexão com Dify.' } })
  }
  res.end()
}

async function handleDifyUpload(req, res) {
  if (!difyApiKey) return json(res, 503, { error: 'DIFY_API_KEY não foi configurada no servidor.' })
  let user
  try { user = await authenticate(req) } catch (error) { return json(res, 401, { error: error.message }) }
  const contentType = req.headers['content-type'] || ''
  if (!contentType.includes('multipart/form-data')) return json(res, 400, { error: 'Envie um arquivo no formato multipart.' })
  const bytes = await readBodyBuffer(req)
  const incoming = await new Request('http://aetel.local/upload', { method: 'POST', headers: { 'content-type': contentType }, body: bytes }).formData()
  const outgoing = new FormData()
  const uploadedFile = incoming.get('file')
  if (!(uploadedFile instanceof Blob)) return json(res, 400, { error: 'Arquivo ausente.' })
  outgoing.append('file', uploadedFile, uploadedFile.name || 'upload.bin')
  outgoing.append('user', user.id)
  const response = await fetch(`${difyBaseUrl}/files/upload`, { method: 'POST', headers: { Authorization: `Bearer ${difyApiKey}` }, body: outgoing })
  const body = await response.text()
  if (!response.ok) { res.writeHead(response.status, { 'Content-Type': 'application/json' }); return res.end(body) }
  const file = JSON.parse(body)
  return json(res, 200, { id: file.id, type: 'file', size_bytes: file.size ?? file.size_bytes ?? uploadedFile.size, created_at: typeof file.created_at === 'number' ? new Date(file.created_at * 1000).toISOString() : (file.created_at || new Date().toISOString()), filename: file.name || file.filename || uploadedFile.name || 'arquivo', mime_type: file.mime_type || uploadedFile.type || 'application/octet-stream' })
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8' }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`)
  if (url.pathname === '/' && url.searchParams.has('code')) {
    res.writeHead(302, {
      Location: `/chat${url.search}`,
      'Cache-Control': 'no-store',
    })
    return res.end()
  }
  if (url.pathname === '/api/config' && req.method === 'GET') {
    return json(res, 200, { supabaseUrl, supabaseAnonKey, configured: Boolean(supabaseUrl && supabaseAnonKey), authDisabled: localAuthDisabled })
  }
  if (url.pathname === '/api/admin/application-status' && req.method === 'POST') {
    try { return await handleApplicationStatus(req, res) } catch (error) {
      return json(res, 502, { error: error instanceof Error ? error.message : 'Falha ao atualizar a candidatura.' })
    }
  }
  if (url.pathname === '/api/anthropic/v1/messages' && req.method === 'POST') {
    try { return await handleDify(req, res) } catch (error) { return json(res, 502, { error: error instanceof Error ? error.message : 'Falha no servidor.' }) }
  }
  if (url.pathname === '/api/anthropic/v1/files' && req.method === 'POST') {
    try { return await handleDifyUpload(req, res) } catch (error) { return json(res, 502, { error: error instanceof Error ? error.message : 'Falha no envio do arquivo.' }) }
  }
  if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'Endpoint não encontrado.' })

  if (url.pathname === '/research-news.html' || url.pathname === '/careers.html') {
    const destination = url.pathname === '/research-news.html' ? '/research-news' : '/careers'
    res.writeHead(308, { Location: `${destination}${url.search}`, 'Cache-Control': 'no-store' })
    return res.end()
  }
  const siteRoute = /^\/(research-news|careers|admin)\/?$/.test(url.pathname)
  let filePath = siteRoute
    ? path.join(dist, 'chat/index.html')
    : path.resolve(dist, `.${decodeURIComponent(url.pathname)}`)
  if (!filePath.startsWith(`${dist}${path.sep}`) && filePath !== dist) return json(res, 403, { error: 'Acesso negado.' })
  try {
    const info = await stat(filePath)
    if (info.isDirectory()) filePath = path.join(filePath, 'index.html')
    const body = await readFile(filePath)
    res.writeHead(200, {
      'Content-Type': mime[path.extname(filePath)] || 'application/octet-stream',
      ...(path.extname(filePath) === '.html' || path.basename(filePath) === 'site-locale.js'
        ? { 'Cache-Control': 'no-store' }
        : {}),
    })
    return res.end(body)
  } catch {
    try {
      const body = await readFile(path.join(dist, 'index.html'))
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
      })
      return res.end(body)
    } catch { return json(res, 503, { error: 'Execute npm run build antes de iniciar o servidor.' }) }
  }
})

const host = localAuthDisabled ? '127.0.0.1' : '0.0.0.0'
server.listen(port, host, () => console.log(localAuthDisabled
  ? `Sharko local sem login em http://${host}:${port}`
  : `Sharko online na porta ${port}`))
