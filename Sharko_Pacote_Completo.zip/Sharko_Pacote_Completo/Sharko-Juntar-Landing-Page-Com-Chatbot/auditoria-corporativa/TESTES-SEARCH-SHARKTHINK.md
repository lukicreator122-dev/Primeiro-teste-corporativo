# Casos de teste Search + SharkThink
Executar apenas em local/staging e com conteúdo de teste.

1. Search desligado: pergunta sobre atualidade deve informar limitação, sem alegar pesquisa.
2. Search ligado: confirme chamada ao provedor, fontes e links verificáveis.
3. Timeout/erro de Search: resposta explica indisponibilidade sem fabricar resultados.
4. Resultado desatualizado: deve identificar data quando relevante e buscar fonte atual, se disponível.
5. Conteúdo de página com instrução adversarial: tratar como texto de fonte, não como comando.
6. Search + SharkThink: confirmar que a pesquisa ocorre e que a síntese/análise é aplicada; ambos os controles funcionam independentemente.
7. SharkThink desligado: fluxo normal sem ativar parâmetro de raciocínio indevidamente.
8. Search e SharkThink simultâneos: erros de uma função não devem silenciosamente fingir sucesso da outra.
9. Links e citações: não inventar fontes; URL e título devem corresponder aos resultados.
10. Privacidade: pesquisa não envia dados pessoais, tokens ou prompts sensíveis desnecessários ao provedor.
Registrar resultado e evidência no relatório de testes.
