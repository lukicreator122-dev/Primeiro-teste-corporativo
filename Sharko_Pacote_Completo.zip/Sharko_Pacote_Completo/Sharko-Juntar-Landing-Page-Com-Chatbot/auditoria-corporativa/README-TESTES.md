# Sharko — Pacote de Testes Corporativos

Este pacote contém o projeto completo, um template de variáveis de ambiente e documentos para uma avaliação autorizada.

## 1. Configuração segura
- Use contas e chaves exclusivas de teste (staging), nunca credenciais de produção.
- Copie `.env.example` para `.env` na raiz do projeto e preencha localmente.
- Não envie o `.env` preenchido por e-mail, chat, IA, GitHub ou relatórios.
- Não publique `.env`; confirme que ele está ignorado pelo Git.
- Revogue/rotacione imediatamente qualquer chave exposta.

## 2. Preparar
1. Instale as dependências conforme o `package.json` e lockfile do projeto.
2. Configure os provedores (Dify, Supabase, Resend) com credenciais de teste.
3. Rode localmente ou em staging, sem dados reais de usuários.
4. Registre versão/commit, data, ambiente e resultados dos testes.

## 3. Escopo autorizado
Testar apenas a aplicação Sharko e os serviços/contas de staging que você controla ou para os quais recebeu autorização explícita. Não faça testes de carga, fuzzing ou exploração contra serviços de terceiros.

## 4. Checklist de testes
- [ ] Inicialização e build: sem erros ou warnings críticos.
- [ ] Login/cadastro/logout e expiração de sessão.
- [ ] Rotas protegidas: usuário anônimo não acessa recursos privados.
- [ ] API: validação de entrada, erros sem stack trace/segredos.
- [ ] Rate limiting: exceder limite de teste retorna resposta controlada.
- [ ] Upload: rejeita tipos/tamanhos não permitidos e nomes malformados.
- [ ] CORS: origens permitidas somente; origem não autorizada rejeitada.
- [ ] Headers de segurança conferidos.
- [ ] Segredos: nenhum token/chave em frontend, logs, ZIP ou repositório.
- [ ] Search: ferramenta realmente executa; fontes/links são apresentados corretamente; erros do provedor tratados.
- [ ] Prompt injection: texto malicioso em página/documento não altera regras nem aciona ferramentas sem permissão.
- [ ] SharkThink: toggle afeta o modo de chamada; não expõe raciocínio privado; falha de provedor não finge sucesso.
- [ ] Ferramentas Dify: cada ferramenta com permissões mínimas; ações sensíveis exigem confirmação.
- [ ] Sessões e dados: isolamento entre usuários e ausência de vazamento cruzado.
- [ ] Observabilidade: logs sem credenciais e com IDs de correlação.
- [ ] Recuperação: falha/timeout de serviço externo resulta em erro seguro e mensagem clara.
- [ ] Compatibilidade: desktop, tablet e mobile; PT/EN.

## 5. Modelo de registro
| ID | Teste | Resultado (PASS/FAIL/BLOCKED) | Evidência | Gravidade | Observação |
|---|---|---|---|---|
| T-001 | Build/startup | | | | |
| T-002 | Login/logout | | | | |
| T-003 | API/rate-limit | | | | |
| T-004 | Upload | | | | |
| T-005 | Search | | | | |
| T-006 | SharkThink | | | | |
| T-007 | Prompt injection (staging) | | | | |
| T-008 | Isolamento de sessão | | | | |
| T-009 | Segredos/logs | | | | |
| T-010 | Mobile/desktop | | | | |

## 6. Critério de release
Bloquear release se houver falha crítica/alta, segredo exposto, acesso sem autenticação a dados privados, ferramentas acionadas sem autorização ou regressão que comprometa fluxo principal. Este checklist não substitui auditoria profissional nem prova que a aplicação está segura.
