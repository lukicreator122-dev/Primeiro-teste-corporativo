# Relatório de Teste — Sharko

- Data/hora:
- Versão/commit:
- Ambiente (staging/local):
- Responsável:
- Escopo e autorização:

## Resumo
- Testes executados:
- PASS:
- FAIL:
- BLOCKED:
- Risco residual:
- Recomendação de release: APROVAR / REPROVAR / APROVAR COM RESSALVAS

## Achados
Para cada achado, registrar: ID, descrição, impacto, severidade (Crítica/Alta/Média/Baixa), passos de reprodução, evidência sem dados sensíveis, mitigação e responsável.

## Evidências
Não incluir tokens, passwords, dados pessoais, cookies, cabeçalhos de autorização ou conteúdo de usuários.
