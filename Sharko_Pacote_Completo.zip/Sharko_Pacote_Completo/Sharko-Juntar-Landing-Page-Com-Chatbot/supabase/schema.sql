create extension if not exists pgcrypto;

create or replace function public.is_sharko_admin()
returns boolean
language sql
stable
set search_path = ''
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

revoke all on function public.is_sharko_admin() from public;
grant execute on function public.is_sharko_admin() to anon, authenticated;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.news_articles (
  id uuid primary key default gen_random_uuid(),
  title_en text not null,
  title_pt text not null,
  summary_en text not null default '',
  summary_pt text not null default '',
  body_en text not null,
  body_pt text not null,
  is_published boolean not null default true,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  department text not null default '',
  location text not null,
  employment_type text not null,
  description text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);

create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete restrict,
  full_name text not null check (length(trim(full_name)) between 2 and 160),
  email text not null check (length(trim(email)) <= 320),
  phone text not null default '',
  linkedin_url text not null default '',
  resume_url text not null default '',
  cover_letter text not null default '',
  status text not null default 'new'
    check (status in ('new', 'reviewing', 'interview', 'hired', 'rejected')),
  admin_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.job_applications
  add column if not exists resume_url text not null default '';
alter table public.job_applications
  add column if not exists decision_email_sent_at timestamptz;

create index if not exists news_articles_published_at_idx
  on public.news_articles (published_at desc)
  where is_published;
create index if not exists jobs_active_created_at_idx
  on public.jobs (created_at desc)
  where is_active;
create index if not exists job_applications_job_id_created_at_idx
  on public.job_applications (job_id, created_at desc);

drop trigger if exists news_articles_set_updated_at on public.news_articles;
create trigger news_articles_set_updated_at
before update on public.news_articles
for each row execute function public.set_updated_at();

drop trigger if exists jobs_set_updated_at on public.jobs;
create trigger jobs_set_updated_at
before update on public.jobs
for each row execute function public.set_updated_at();

drop trigger if exists job_applications_set_updated_at on public.job_applications;
create trigger job_applications_set_updated_at
before update on public.job_applications
for each row execute function public.set_updated_at();

alter table public.news_articles enable row level security;
alter table public.jobs enable row level security;
alter table public.job_applications enable row level security;

drop policy if exists "Published news is public" on public.news_articles;
create policy "Published news is public"
on public.news_articles for select to anon, authenticated
using (is_published or public.is_sharko_admin());

drop policy if exists "Admins manage news" on public.news_articles;
create policy "Admins manage news"
on public.news_articles for all to authenticated
using (public.is_sharko_admin())
with check (public.is_sharko_admin());

drop policy if exists "Active jobs are public" on public.jobs;
create policy "Active jobs are public"
on public.jobs for select to anon, authenticated
using (is_active or public.is_sharko_admin());

drop policy if exists "Admins manage jobs" on public.jobs;
create policy "Admins manage jobs"
on public.jobs for all to authenticated
using (public.is_sharko_admin())
with check (public.is_sharko_admin());

drop policy if exists "Public can apply to active jobs" on public.job_applications;
create policy "Public can apply to active jobs"
on public.job_applications for insert to anon, authenticated
with check (
  status = 'new'
  and admin_notes is null
  and exists (
    select 1
    from public.jobs
    where jobs.id = job_applications.job_id
      and jobs.is_active
  )
);

drop policy if exists "Admins read applications" on public.job_applications;
create policy "Admins read applications"
on public.job_applications for select to authenticated
using (public.is_sharko_admin());

drop policy if exists "Admins update applications" on public.job_applications;
create policy "Admins update applications"
on public.job_applications for update to authenticated
using (public.is_sharko_admin())
with check (public.is_sharko_admin());

revoke all on public.news_articles, public.jobs, public.job_applications from anon, authenticated;
grant select on public.news_articles, public.jobs to anon, authenticated;
grant insert, update, delete on public.news_articles, public.jobs to authenticated;
grant insert (job_id, full_name, email, phone, linkedin_url, resume_url, cover_letter)
  on public.job_applications to anon, authenticated;
grant select, update on public.job_applications to authenticated;
